-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: college_erp
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `screen_data`
--

DROP TABLE IF EXISTS `screen_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `screen_data` (
  `id` int DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `imagepath` varchar(100) DEFAULT NULL,
  `title_data` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screen_data`
--

LOCK TABLES `screen_data` WRITE;
/*!40000 ALTER TABLE `screen_data` DISABLE KEYS */;
INSERT INTO `screen_data` VALUES (1,'About the Department','abcs','The Department of Computer Science & Engineering was established in the year 1986. Since  then, the department has held a position of pride in NITK. It has consistently fulfilled its role of producing Computer Engineers ready to meet the demands of the IT world. The department has always attracted the best of engineering aspirants from all over the country. It has a well qualified and experienced team of faculty. The Department offers B.Tech., M.Tech., M.Tech.(By Research) and Ph.D. courses in Computer Science and Engineering. The department has adequate facilities to support these teaching activities. Students of the department have access to sufficient high end computing facilities. The Department is also actively involved in various research activities. The facilities are adequate to cater to the needs of Research activities. The department has signed MoU with IBM, Intel, Leeds Metropolitan University and others, for academic collaborative projects.\n');
/*!40000 ALTER TABLE `screen_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-15 22:36:58
